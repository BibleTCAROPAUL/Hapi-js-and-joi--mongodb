const express=require('express');
const app=express();
const mongoose=require('mongoose');
const MongoClient = require('mongodb').MongoClient;
app.use(express.json());

//DB CONNECTION
mongoose.connect('mongodb://0.0.0.0:27017/apolloapi', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('CONNECTED TO MONGO!');
    })
    .catch((err) => {
        console.log('OH NO! MONGO CONNECTION ERROR!');
        console.log(err);
    })

    //SCHEMA

const sch={
    project_name :String,
    description:String,
    consumer_name:String,
    id:Number
        }
const monmodel=mongoose.model("PROJECT",sch);

//POST

app.post("/post",async(req,res)=>{
    console.log("inside post function");

    const data=new monmodel({
        project_name:req.body.project_name,
        description:req.body.description,
        consumer_name:req.body.consumer_name,
        id:req.body.id
    });
    const val=await data.save();
    res.json(val);
    })
    // FETCH GET

    app.get('/fetch/:id',function(req,res){
        fetchid=req.params.id;
        monmodel.find(({id:fetchid}),function(err,val){
            if(err)
            {
                res.send("ERROR")
            }else{

            if(val.length==0)//[]
            {
                res.send("data does not exists");
            }else{
                res.send(val);
            }
        }
        })
    })

   
    //FETCH ALL

    app.get("/fetchall",(req,res)=>{

        monmodel.find((err,val)=>{
            if(err)
            {
                console.log(err)
            }else{
                res.json(val)
            }
        })
    })

//PUT
app.put("/update/:id",async(req,res)=>{
        
    let upid=req.params.id;
    let upconsumer_name=req.body.consumer_name;
    let upproject_name=req.params.project_name;
    let updescription=req.params.description;
   
   
 //find id
//update
    monmodel.findOneAndUpdate({id:upid},{$set:{consumer_name:upconsumer_name,project_name:upproject_name,description:updescription}},
    
        {new:true},(err,data)=>{
            if(err)
            {
                res.send("ERROR")
            }
            else{

            if(data==null)
            {
                res.send("nothing found")
            }else{
            res.send(data)
            }
        }
    
    
    })
})

//DELETE

app.delete('/del/:id',function(req,res){
    let delid=req.params.id;

    monmodel.findOneAndDelete(({id:delid}),function(err,docs){
       if(err)
       {
           res.send("ERROR")
       }
       else{
           if(docs==null)
       {
           res.send("WRONG ID")

       }
       else
       {
       res.send(docs);
       }

       }
       

    })
})


    app.listen(3000,() =>{
        console.log('Connected to PORT 3000...');
    })

