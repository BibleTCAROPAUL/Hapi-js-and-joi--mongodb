const Hapi = require("hapi");
const Mongoose = require("mongoose");
const insertfunction=require("./functions").insertapi;


const server = Hapi.Server({ host: "localhost", port: 3000 });
//insertfunction();
//GET

server.route({
    method: "GET",
    path: "/",

    handler: insertfunction()
     
   

});


server.start()


