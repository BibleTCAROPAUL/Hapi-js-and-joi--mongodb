module.exports={
    insertapi:function(){
        
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://0.0.0.0:27017/apolloapi";

MongoClient.connect('mongodb://0.0.0.0:27017', function (err, client) {
  if (err) throw err;

  var db = client.db('apolloapi');
  
   var myobj = { project_name: "Ajeet Kumar", description: "api creation", consumer_name: "Delhi", id:"9" };  
   db.collection("projects").insertOne(myobj, function(err, res) 
   {  
   if (err) throw err;  
   console.log("1 record inserted");  
   db.close();
   })
   
});
    }
}