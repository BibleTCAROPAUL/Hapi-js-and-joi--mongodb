server.route({
    method: "POST",
    path: "/person",
    
    handler: async (request, h) => {
        try {
            var person = new PersonModel(request.payload);
            var result = await person.save();
            return h.response(result);
        } catch (error) {
            return h.response(error).code(500);
        }
    }
});

// old one
server.route({
    method: "POST",
    path: "/person",
    options: {
        validate: {
            payload: {
                projectname: joi.string().required,
                description: joi.string().required,
                consumername: joi.string().required,
                
                
            },
            failAction: (request, h, error) => {
                return error.isjoi ? h.response(error.details[0]).takeover() : h.response(error).takeover();
            }
        }
    },
    handler: async (request, h) => {
        try {
            var person = new PersonModel(request.payload);
            var result = await person.save();
            return h.response(result);
        } catch (error) {
            return h.response(error).code(500);
        }
    }
});
//
//
server.route({
    method: "POST",
    path: "/person",
    
    handler: async (request, h) => {
        try {
            var person = new personModel(request.payload);
            var result = await person.save();
            return h.response(result);
        } catch (error) {
            return h.response(error).code(500);
        }
    }
});


server.listen(3000,() =>{
    console.log('Connected to PORT 3000...');
})